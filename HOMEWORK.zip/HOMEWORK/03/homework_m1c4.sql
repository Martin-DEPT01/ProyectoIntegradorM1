SELECT * FROM customers c 

SELECT * FROM employees e

SELECT * FROM sales s 
ORDER BY productcode 

--Usar una subconsulta no correlacionada para listar los productos con un precio mayor al promedio general de todos los productos vendidos.
SELECT PRODUCTCODE, PRODUCTNAME, PRICEEACH FROM sales s 
WHERE priceeach > (SELECT AVG(PRICEEACH) FROM sales s )


--Utilizar una subconsulta correlacionada para encontrar los productos cuyo precio es mayor al promedio de su línea de producto (PRODUCTLINE).
SELECT PRODUCTCODE, PRODUCTNAME, PRICEEACH, productline  FROM sales A
WHERE PRICEEACH > 
(SELECT AVG(PRICEEACH) FROM sales B
WHERE B.productline = A.productline)
ORDER BY 4


--Reescribir la consulta del punto 1.b usando una CTE en lugar de subconsulta correlacionada.
WITH PROMEDIO_PRODUCTLINE AS (
SELECT PRODUCTLINE, AVG(PRICEEACH) PROMEDIO FROM sales B
GROUP BY PRODUCTLINE
)

SELECT PRODUCTCODE, PRODUCTNAME, PRICEEACH, S.PRODUCTLINE, PROMEDIO  FROM sales S
INNER JOIN PROMEDIO_PRODUCTLINE PPROD
ON S.PRODUCTLINE = PPROD.PRODUCTLINE
WHERE S.PRICEEACH > PPROD.PROMEDIO


--Calcular el porcentaje de clientes cuyo campo state es NULL en la tabla customers.
SELECT COUNT(STATE), COUNT(*) FROM customers c 


WITH STATE_NULL AS (
SELECT CAST(COUNT(*) AS REAL) STATE_NULL FROM customers
WHERE STATE IS NULL
),
TOTAL_CLIENTS AS (
SELECT CAST(COUNT(*) AS REAL) TOTAL_CLIENTS FROM customers
)

SELECT (STATE_NULL/TOTAL_CLIENTS)*100 PORC_STATE_NULL
FROM STATE_NULL, TOTAL_CLIENTS


--Obtener todos los empleados que reportan directa o indirectamente a Mariana (id = 4) y Ricardo (id = 7). Asegúrate de incluir un campo root_id para indicar a cuál jefe se conecta cada empleado.

WITH RECURSIVE OBTENER_EMPLEADOS(ID,NAME,BOSS_ID,NIVEL) AS (

SELECT ID, NAME, BOSS_ID, 1 FROM employees e 
WHERE BOSS_ID IN (4,7)


UNION ALL

SELECT e.ID, e.NAME, e.BOSS_ID, NIVEL +1 FROM employees e 
INNER JOIN OBTENER_EMPLEADOS OE
ON e.boss_id = OE.ID
)

SELECT * FROM OBTENER_EMPLEADOS


--Aplicar ROW_NUMBER() para identificar registros duplicados en la tabla sales, considerando ORDERNUMBER, PRODUCTCODE, y QUANTITYORDERED.
SELECT * FROM 
(
SELECT *, ROW_NUMBER() OVER(PARTITION BY ORDERNUMBER, PRODUCTCODE, QUANTITYORDERED) AS CANTIDAD
FROM sales s 
)
WHERE CANTIDAD > 1


--Usar RANK() y DENSE_RANK() para generar un ranking de ventas (sales) por año (YEAR_ID), ordenadas de mayor a menor.
SELECT *, RANK() OVER(PARTITION BY YEAR_ID ORDER BY SALES DESC) RANKING_VENTAS,
DENSE_RANK() OVER(PARTITION BY YEAR_ID ORDER BY SALES DESC) DENSE_RANKING_VENTAS
FROM sales s
ORDER BY RANKING_VENTAS



--Usar LAG() para calcular la variación porcentual de ventas por mes respecto al mes anterior, dentro de cada año.
SELECT *,
SUM(SALES) OVER (PARTITION BY YEAR_ID, MONTH_ID) AS TOTAL_VENTAS,
LAG(SALES) OVER (PARTITION BY YEAR_ID,MONTH_ID ORDER BY MONTH_ID) AS MES_ANTERIOR FROM sales



WITH TOTAL_VENTAS AS (

SELECT YEAR_ID,MONTH_ID, SUM(SALES) TOTAL_VENTAS_MES
FROM SALES
GROUP BY YEAR_ID,MONTH_ID
),

TOTAL_VENTAS_MES_ANTERIOR AS (

SELECT *, LAG(TOTAL_VENTAS_MES) OVER (PARTITION BY YEAR_ID ORDER BY MONTH_ID) AS MES_ANTERIOR
FROM TOTAL_VENTAS
)

SELECT *, 
ROUND((TOTAL_VENTAS_MES - MES_ANTERIOR)/MES_ANTERIOR,4)*100.0 AS VARIACION_CON_MES_ANTERIOR
FROM TOTAL_VENTAS_MES_ANTERIOR



--Usar LEAD() para mostrar las ventas del mes siguiente junto a las actuales.

WITH TOTAL_VENTAS AS (

SELECT YEAR_ID,MONTH_ID, SUM(SALES) TOTAL_VENTAS_MES
FROM SALES
GROUP BY YEAR_ID,MONTH_ID
)

SELECT *, LEAD(TOTAL_VENTAS_MES) OVER (PARTITION BY YEAR_ID ORDER BY YEAR_ID,MONTH_ID) AS MES_SIGUIENTE
FROM TOTAL_VENTAS




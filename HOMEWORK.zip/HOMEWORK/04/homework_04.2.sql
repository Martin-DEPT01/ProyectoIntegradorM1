SET GLOBAL log_bin_trust_function_creators = 1;
SET SQL_SAFE_UPDATES = 0;

USE HENRY;

SELECT * FROM estudiantes;
SELECT * FROM materias;
SELECT * FROM inscripciones;
SELECT * FROM calificaciones;
SELECT * FROM estudiantes,auditoria_eliminaciones;

-- Crear un trigger que registre en auditoria_eliminaciones los datos de un estudiante al ser eliminado.
DELIMITER //
CREATE TRIGGER alumno_eliminado 
BEFORE DELETE ON estudiantes
FOR EACH ROW 
BEGIN
	INSERT INTO auditoria_eliminaciones (ESTUDIANTE_ID,EMAIL,ELIMINADO_EN)
	VALUES (OLD.ID,OLD.EMAIL,NOW());
END; //
DELIMITER ;

-- Crear un trigger que actualice el estado académico del estudiante al insertar una calificación.
DELIMITER //
CREATE TRIGGER estado_alumno 
AFTER INSERT ON calificaciones
FOR EACH ROW 
BEGIN
	IF EXISTS (SELECT 1 FROM estudiantes WHERE ID = NEW.ESTUDIANTE_ID) THEN
		BEGIN
			UPDATE estudiantes
			SET ESTADO = 'activo'
			WHERE ID = NEW.ESTUDIANTE_ID;
		END;
	ELSE 
    -- el siguiente bloque no hace falta porque hay una constraint entre estudiantes.id y calificaciones.estudiante_id
	-- Error Code: 1452. Cannot add or update a child row: a foreign key constraint fails (`henry`.`calificaciones`, CONSTRAINT `calificaciones_ibfk_1` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiantes` (`id`))
		BEGIN
			SET @MENSAJE = CONCAT('EL ESTUDIANTE ' , NEW.ESTUDIANTE_ID, '  NO EXISTE');
			SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = @MENSAJE;
		END;
	END IF;
END; //
DELIMITER ;

DROP TRIGGER estado_alumno;

INSERT INTO calificaciones (estudiante_id, materia_id, nota, fecha) VALUES
(2, 1, 8.5, NOW());


-- Desarrollar un procedimiento para registrar calificaciones, validando que la nota esté entre 0 y 10.
DELIMITER //
CREATE PROCEDURE registrar_calificacion(
	IN ESTUDIANTE INT,
    IN MATERIA INT,
	IN CALIFICACION INT,
    IN FECHA DATE
)
BEGIN
	-- IF CALIFICACION BETWEEN 0 A 10 THEN
	IF (CALIFICACION < 0 OR CALIFICACION > 10) THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Error: Calificacion incorrecta. Debe ser entre 0 y 10';
	ELSE
		BEGIN
			INSERT INTO calificaciones (estudiante_id, materia_id, nota, fecha)
            VALUES (ESTUDIANTE, MATERIA, CALIFICACION, FECHA);
            SET @MENSAJE = 'LA CALIFICACION SE INSERTO CORRECTAMENTE';
            SELECT @MENSAJE AS MENSAJE;
		END;
	END IF;
END; //

DELIMITER ;

CALL registrar_calificacion(3,3,4,DATE(NOW()));
CALL registrar_calificacion(3,3,11,DATE(NOW()));
CALL registrar_calificacion(2,3,10,DATE(NOW()));


-- Crear un procedimiento para inscribir estudiantes en materias, verificando su estado activo.
SELECT * FROM inscripciones;
SELECT * FROM estudiantes;

DELIMITER //
CREATE PROCEDURE inscribir_estudiante (
	IN estudiante INT,
    IN materia INT,
    IN fecha date
)
BEGIN
	SET @ESTADO = (SELECT ESTADO FROM estudiantes WHERE id = estudiante);
	IF (@ESTADO != 'activo') THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Error: El estudiante no esta activo';
	ELSEIF (@ESTADO = 'activo') THEN
		INSERT INTO inscripciones (estudiante_id,materia_id,fecha)
        VALUES (estudiante,materia,fecha);
	END IF;
END; //

DELIMITER ;

-- CALL inscribir_estudiante(1,1,NOW());


-- Función para calcular el promedio de un estudiante.
SELECT * FROM calificaciones;
SELECT * FROM estudiantes;

DELIMITER //
CREATE FUNCTION promedio_estudiante(
	estudiante INT
) RETURNS DECIMAL(4,2)
BEGIN
    -- DECLARE promedio DECIMAL(4,2);
    -- SELECT AVG(nota) INTO promedio 
    -- FROM calificaciones WHERE estudiante_id = estudiante
    -- RETURN promedio;
	SET @PROMEDIO = (SELECT AVG(nota) FROM calificaciones WHERE estudiante_id = estudiante);
	RETURN ROUND(@PROMEDIO,2);
END; //

DELIMITER ;

SELECT *, promedio_estudiante(id) AS PROMEDIO
FROM estudiantes;
SELECT promedio_estudiante(3) as promedio;

-- Función para determinar el estado académico (ej: "Aprobado" si promedio ≥ 6).
DELIMITER //
CREATE FUNCTION estado_academico(
	promedio DECIMAL
)	RETURNS VARCHAR(20)
BEGIN
	DECLARE v_aprobado INT;
    SET v_aprobado = 6;
    IF (promedio >= v_aprobado) THEN
		RETURN 'Aprobado';
	ELSE
		RETURN 'Desaprobado';
	END IF;
END; //

DELIMITER ;

SELECT *, promedio_estudiante(id) AS PROMEDIO, estado_academico(promedio_estudiante(id)) AS ESTADO_ACADEMICO
FROM estudiantes;

-- OTRO ENFOQUE
DELIMITER //
CREATE FUNCTION estado_academico2(
	estudiante INT
)	RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
	DECLARE v_aprobado INT;
    SET v_aprobado = 6;
    IF (promedio_estudiante(estudiante) >= v_aprobado) THEN
		RETURN 'Aprobado';
	ELSE
		RETURN 'Desaprobado';
	END IF;
END; //

DELIMITER ;

SELECT *, promedio_estudiante(id) AS PROMEDIO, estado_academico2(id) AS ESTADO_ACADEMICO
FROM estudiantes;


-- OTRO ENFOQUE MAS (CLASE EN VIVO):

DELIMITER //
CREATE FUNCTION fn_estado_academico(estudiante_id INT)
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
	DECLARE estado VARCHAR(20);
    DECLARE promedio DECIMAL(4,2);
    SET promedio = promedio_estudiante(estudiante_id);
    IF promedio >= 6 THEN
		SET estado = 'Aprobado';
	ELSE
		SET estado = 'Desaprobado';
	END IF;
    RETURN estado;
END; //
DELIMITER ;

-- Vista que muestre el rendimiento de estudiantes con su promedio y estado.
CREATE VIEW VW_RENDIMIENTO_ESTUDIANTES AS
SELECT ID, NOMBRE, ESTADO, promedio_estudiante(id) AS PROMEDIO, 
estado_academico2(id) AS ESTADO_ACADEMICO
FROM estudiantes;
-- WHERE ESTADO = 'Activo';


SELECT * FROM VW_RENDIMIENTO_ESTUDIANTES;


-- Vista que liste las materias con el promedio general de calificaciones.
SELECT * FROM materias;
SELECT * FROM calificaciones;


DELIMITER //
CREATE FUNCTION promedio_materia(
	materia INT
) RETURNS DECIMAL(4,2)
BEGIN
	SET @PROMEDIO = (SELECT AVG(nota) FROM calificaciones WHERE materia_id = materia);
	RETURN ROUND(@PROMEDIO,2);
END; //

DELIMITER ;


CREATE VIEW calificacion_materia_vw AS
SELECT *, promedio_materia(id) FROM materias;

CREATE VIEW calificacion_materia_vw2 AS
SELECT M.id, nombre, creditos, ROUND(AVG(nota),2) AS PROMEDIO_GENERAL 
FROM materias M
-- INNER JOIN calificaciones C
LEFT JOIN calificaciones C
ON M.id = c.materia_id
GROUP BY M.id
ORDER BY M.id;

SELECT * FROM calificacion_materia_vw;
SELECT * FROM calificacion_materia_vw2;

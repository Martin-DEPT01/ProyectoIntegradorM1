USE HENRY;

SELECT * FROM estudiantes
SELECT * FROM materias
SELECT * FROM inscripciones
SELECT * FROM calificaciones
SELECT * FROM auditoria_eliminaciones

CREATE TABLE auditoria_eliminaciones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estudiante_id INT,
    email VARCHAR(255),
    eliminado_en DATETIME
);

--Crear un trigger que registre en auditoria_eliminaciones los datos de un estudiante al ser eliminado.
CREATE TRIGGER estudiante_eliminado
BEFORE DELETE ON estudiantes
FOR EACH ROW
BEGIN
	INSERT INTO auditoria_eliminaciones(ESTUDIANTE_ID,EMAIL,ELIMINADO_EN)
	VALUES (OLD.id,OLD.email,DATETIME('now'));
END;

--DROP TRIGGER estudiante_eliminado
DELETE FROM estudiantes
WHERE ID = 2


--DROP TABLE estudiantes


--Crear un trigger que actualice el estado académico del estudiante al insertar una calificación.
CREATE TRIGGER estado_estudiante
AFTER INSERT ON calificaciones
--SET @ESTUDIANTE = 0
FOR EACH ROW
BEGIN
	--@ESTUDIANTE = SELECT ESTUDIANTE_ID FROM estudiantes WHERE ID = NEW.ESTUDIANTE_ID
	IF EXISTS(SELECT 1 FROM estudiantes WHERE ID = NEW.ESTUDIANTE_ID)
	--CASE
		--WHEN EXISTS (SELECT 1 FROM estudiantes WHERE ID = NEW.ESTUDIANTE_ID)
			BEGIN
				UPDATE estudiantes
				SET ESTADO = 'activo'
				WHERE ID = NEW.ESTUDIANTE_ID;
			END;
	ELSE 
		BEGIN
			SIGNAL SQLSTATE '45000';
    		SET MESSAGE_TEXT = 'Producto no encontrado';
		END
	END IF;
END;


DROP TRIGGER estado_estudiante

INSERT INTO calificaciones (estudiante_id, materia_id, nota, fecha) VALUES
(4, 1, 3, '2024-04-01');


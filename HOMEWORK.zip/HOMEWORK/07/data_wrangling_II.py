#LAS OPERACIONES VECTORIZADAS SE USAN SOBRE SERIES O COLUMNAS COMPLETAS.
#APROVECHA OPTIMIZACIONES INTERNAS DE NUMPY

import pandas as pd
import time

start_time = time.time()  # iniciar cronometro

df = pd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv", 
    parse_dates = ["send_date","open_date"])

#print(df)
# 1) ENFOQUE ITERATIVO:

df["opened_quickly"] = False
for i in df.index:   # -> forma CAVERNICOLA de hacerlo
    if pd.notnull(df.loc[i,"open_date"]):
        delta = df.loc[i,"open_date"] - df.loc[i,"send_date"]
        #print(type(delta))
        if delta.total_seconds() < 21600:
            df.at[i,"opened_quickly"]=True  # Igual que df.loc[i,"opened_quickly"] pero .at no permite rangos y es mas eficiente

print(df)


# 1) ENFOQUE VECTORIZADO:
df2 = pd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv", 
    parse_dates = ["send_date","open_date"])


# .dt -> se usa para acceder a los atributos de fecha y hora para una serie de tipo datetime64
df2["opened_quickly"] = (df["open_date"] - df["send_date"]).dt.total_seconds() < 21600

# (df["open_date"] - df["send_date"]) -> operacion vectorial

print(df2)

#------------------------------------------------------------------------------------

# .map() --> Series

# .apply() --> Seires/DataFrame -> puede cambiar la forma original

# .transform() --> Series(usualmente despues de GROUP BY) -> operaciones de grupo a grupo

# MAP()
df["is_mobile"] = df["device_type"].map(lambda x: x == "mobile")

print(df["is_mobile"])

# APPLY()
def clasificar_usuario(row):
    if row["purchase_amount"] > 50:
        return "comprador alto"
    elif pd.notnull(row["purchase_amount"]):
        return "comprador bajo"
    else:
        return "sin conversión"

df["tipo_usuario"] = df.apply(clasificar_usuario, axis = 1) # axis = 1 es para cada fila

print(df)

# TRANSFORM()
df["normalized_purchase"] = df.groupby("ab_group")["purchase_amount"].transform(
    lambda x: x/x.mean() # mean() es la funcion promedio
)

print(df)

#------------------------------------------------------------------------------------

# Para archivos absurdamente grandes que NO entran en memoria:

# CHUNKSIZE -> permite leer el arhcivo en porciones procesando bloque x bloque en un blucle
# util para transformaciones simples sin necesidad de cargar todo el dataset de una sola vez

# DASK -> Libreria aparte (no pandas) para procesamiento distribuido y escalable
# Replica funciones de pandas pero para datasets grandes como si fueran pequeños
# Internamente divide el trabajo en tareas paralelas. Aprovecha multiples nucleos y bajo el uso de memoria.

# AMBOS sirven para ESCALAR DATOS

# CHUNK
chunker_iter = pd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv", 
    chunksize=50000) # 50000 registros por chunk

for chunk in chunker_iter:
    #(chunk["purchase_amount"] > 0) -> serie booleana
    #(chunk["purchase_amount"] > 0).astype(int) -> convierte la serie booleana a 0 y 1.
    chunk["conversion_rate"] = (chunk["purchase_amount"] > 0).astype(int) # --> no hace falta el astype(int) para calcular mean()
    print(chunk["conversion_rate"].mean())

# DASK

import dask.dataframe as dd # en archivos grandes se usa directamente esta libreria

df_dask = dd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv", 
    parse_dates = ["send_date","open_date"])

conversion_rate = (df_dask["purchase_amount"] > 0).mean().compute() # .compute() se usa en DASK
# compute() es necesario para concretarse la operacion, sino es solamente un objeto dask
print(conversion_rate)
import time
#print(df.groupby("ab_group")["purchase_amount"].mean())
traditional_time = time.time() - start_time
print(f"{traditional_time:.2f}")

# --> USO RECOMENDADO <--

# PANDAS: <500k filas
# CHUNK: 500k - 5M filas
# DASK: >1M filas o distributed


#------------------------------------------------------------------------------------

# pivot() -> reorganiza los datos para que una categoria pase a ser columna

df["converted"] = (df["purchase_amount"] > 0).astype(int)
print(df)
pivot_table = df.pivot_table(values="converted", index="campaign_id", columns="ab_group", aggfunc="mean")
print(pivot_table) # es como si agrupara por index y columns

# melt() -> la operacion opuesta (formato ancho a largo), ideal para graficar 
# se usa para revertir pivots por ejemplo

pivot_reset = pivot_table.reset_index()
print(pivot_reset)
melted = pivot_reset.melt(id_vars="campaign_id", value_vars=["A","B"], var_name="ab_group", value_name="conversion_rate")
print(melted)

# groupby()

df["opened"] = pd.notnull(df["open_date"]).astype(int)
device_group = df.groupby("device_type")["opened"].mean()

print(device_group)  # -> Series

# agg()
# sirve para agregacion multiple

region_group = df.groupby("region")["purchase_amount"].agg(["mean","sum","count"])

print(type(region_group))
print(region_group) # -> DataFrame


#------------------------------------------------------------------------------------

#FUNCION LAMBDA -> funcion anonima de una sola linea

# utiles para usar en apply() y transform()

# transform()
df["above_avg_purchase"] = df.groupby("ab_group")["purchase_amount"].transform( # -> devuelve Series
    lambda x: x > x.mean() # --> a cada elemento dentro del agrupado por "ab_group" se le aplica transf lambda
)

print(df)
print("----")

# apply() --> permite modificar varias columnas a la vez
print(df[["campaign_id","purchase_amount"]])
def etiquetar_campaña(grupo):  # grupo (DataFrame) -> todos los registros dentro de cada grupo de "campaign_id" 
    tasa = (grupo["purchase_amount"] > 0).mean()
    grupo["tasa"] = tasa
    grupo["etiqueta"] = "exitosa" if tasa > 0.4 else "regular"
    return grupo

df = df.groupby("campaign_id").apply(etiquetar_campaña)

print(df)

#------------------------------------------------------------------------------------
# BETWEEN
# df[~df["age"].between(18, 100)]

# CLAVES DUPLICADAS
# df.duplicated(subset=["user_id","campaign_id"]).sum()

#  PANDERA ---> es una libreria que permite definir que estructura deben tener los datos y se verifica
#               automaticamente si la cumplen

import pandera as pa
from pandera import Column, DataFrameSchema, Check

schema = DataFrameSchema ({
    "age": Column(pa.Int, Check.in_range(18,100)),
    "purchase_amount": Column(pa.Float, Check.ge(0), nullable=True),
    "send_date": Column(pa.DateTime),
    "open_date": Column(pa.DateTime, nullable=True)
})

schema.validate(df) # -> si alguna fila no cumple el esquema lanza error

# EJEMPLO: Analizar la campaña 047 ya que  reportaron una conversion inusualmente baja

#1. Cargar el dataset filtrado
#2. Detectar valores nulos en campos criticos
#3. Identificar edades invalidas
#4. Detectar clikc antes del envio de mail
#5. Validar el esquema con Pandera

df_pandera = pd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv", 
    parse_dates = ["send_date","open_date"],
    na_values=["","NA"])

#Filtrar la campaña sospechosa
campaña = df_pandera[df_pandera["campaign_id"] == "camp002"].copy()
campaña.isnull().sum()

print("Edades fuera de rango (18-100):")
print(df_pandera[(df_pandera["age"] < 18) | (df_pandera["age"] > 100)])

errores_tiempo = campaña[campaña["click_date"] < campaña["send_date"]]
errores_tiempo[["user_id", "send_date", "click_date"]]

schema = DataFrameSchema({
    "user_id": Column(pa.String),
    "age": Column(pa.Int, Check.in_range(18,100)),
    "purchase_amount": Column(pa.Float, Check.ge(0), nullable=True),
    "send_date": Column(pa.DateTime),
    "open_date": Column(pa.DateTime, nullable=True),
    "click_date": Column(pa.DateTime, nullable=True),
    "region": Column(pa.String, nullable=True)
})

print(df_pandera)
print(errores_tiempo)
print(campaña)
print(campaña.isnull().sum())
print(schema)

#------------------------------------------------------------------------------------

# CONVERSION FECHAS

df = pd.read_csv(
    r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\07\lecture_email_campaign_performance_.csv" 
    )

df["send_date"] = pd.to_datetime(df["send_date"])
df["open_date"] = pd.to_datetime(df["open_date"], errors="coerce") 
# errors="coerce" -> permite que las fechas mas formateadas se transformen en NaT evitando que el codigo falle
df["click_date"] = pd.to_datetime(df["click_date"], errors="coerce")

# si una columna tiene un formato no estandar (ejemplo: "2023/10/05 12:00"), se puede especificar:
df["send_date"] = pd.to_datetime(df["send_date"], format="%Y/%m/%d %H:%M")

print(df[["send_date","open_date","click_date"]])

# IMPORTANTE!! -> una vez convertido a datetime hay accedo al atributo .dt permitiendo extraer partes especificas

df["send_date"] = pd.to_datetime(df["send_date"], errors="coerce")

df["year"] = df["send_date"].dt.year
df["month"] = df["send_date"].dt.month
df["day_of_week"] = df["send_date"].dt.dayofweek # Lunes = 0, Domingo = 6
df["hour"] = df["send_date"].dt.hour

# Se puede analizar que dias convierten mas, o si el horario influye en la apertura de los mails.
# Analisis explotatorio:
df["converted"] = (df["purchase_amount"] > 0).astype(int)

print(df.groupby("day_of_week")["converted"].mean())
print(df.groupby("hour")["converted"].mean())

print(df)

# Agrupacion por PERIODOS

# resample() -> se puede agrupar por unidades fijas temporales (dias, semanas, meses, etc)
# requiere que la fecha este seteada como indice

df.set_index("send_date", inplace=True)
df["opened"] = pd.notnull(df["open_date"]).astype(int)

df.resample("W")["opened"].mean()
print(df.resample("W")["opened"].mean())
# Devuelve la tasa de apertura promedio por semana.

#Ejemplo 2: Agrupacion mensual de conversiones
df["converted"] = (df["purchase_amount"] > 0).astype(int)
df.resample("M")["converted"].mean()
print(df.resample("M")["converted"].mean())
# Permite observar tendencias mensuales y comparar performance entre periodos.

# Ejemplo 3: Agrupacion diaria del volumen de envios
df.resample("D").size()

print(df.resample("D").size())

# Calculo de PERIODOS

df["time_to_open"] = (df["open_date"] - df.index).dt.total_seconds() / 3600
df["time_to_open"].describe()

# Devuelve el tiempo promedio en horas que tardan los usuarios en abrir el corrio desde que se envio.
# Ejemplo aplicado: tiempo hasta click

df["time_to_click"] = (df["click_date"] - df.index).dt.total_seconds() / 60
df[df["time_to_click"] > 0]["time_to_click"].hist(bins=40)

print(df)

#BUSCAR FUNCION "FILTER()"
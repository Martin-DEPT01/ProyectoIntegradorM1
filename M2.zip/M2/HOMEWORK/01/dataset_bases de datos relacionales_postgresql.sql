
-- Tabla departamentos
CREATE TABLE departamentos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100),
    ubicacion VARCHAR(50)
);

INSERT INTO departamentos (id, nombre, ubicacion) VALUES
(1, 'Ventas', 'Piso 1'),
(2, 'TI', 'Piso 3'),
(3, 'Marketing', 'Piso 2'),
(4, 'Recursos Humanos', 'Piso 1'),
(5, 'Finanzas', 'Piso 4'),
(6, 'Investigación', 'Piso 2');

-- Tabla empleados
CREATE TABLE empleados (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    fecha_contratacion DATE,
    correo_electronico VARCHAR(100),
    salario DECIMAL(10,2),
    departamento_id INT,
    FOREIGN KEY (departamento_id) REFERENCES departamentos(id)
);

INSERT INTO empleados (id, nombre, apellido, fecha_contratacion, correo_electronico, salario, departamento_id) VALUES
(1, 'Juan', 'Pérez', '2023-01-01', 'juan.perez@email.com', 5000.00, 1),
(2, 'María', 'Gómez', '2020-04-12', 'maria.gomez@email.com', 6000.00, 1),
(3, 'Carlos', 'López', '1998-09-10', 'carlos.lopez@email.com', 5500.00, 2),
(4, 'Ana', 'Martínez', '2022-05-30', 'ana.martinez@email.com', 6500.00, 3),
(5, 'Pedro', 'Sánchez', '2022-06-29', 'pedro.sanchez@email.com', 7000.00, 2),
(6, 'Laura', 'Rodríguez', '2001-09-13', 'laura.rodriguez@email.com', 5200.00, 4),
(7, 'Diego', 'Fernández', '2022-03-06', 'diego.fernandez@email.com', 5800.00, 5),
(8, 'Sofía', 'García', '2023-08-07', 'sofia.garcia@email.com', 6200.00, 3),
(9, 'Pablo', 'Díaz', '2023-09-18', 'pablo.diaz@email.com', 5400.00, 1),
(10, 'Lucía', 'Moreno', '2024-05-24', 'lucia.moreno@email.com', 5900.00, 2);

-- Tabla proyectos
CREATE TABLE proyectos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100),
    fecha_inicio DATE,
    fecha_fin DATE
);

INSERT INTO proyectos (id, nombre, fecha_inicio, fecha_fin) VALUES
(1, 'Sistema de CRM', '2023-01-15', '2023-06-30'),
(2, 'Migración a la nube', '2023-03-01', '2023-12-15'),
(3, 'Campaña de marketing', '2023-04-01', '2023-05-31'),
(4, 'Automatización', '2023-02-01', '2023-08-31'),
(5, 'Portal del empleo', '2023-05-01', '2023-11-30');

-- Tabla empleado_proyecto
CREATE TABLE empleado_proyecto (
    empleado_id INT,
    proyecto_id INT,
    horas_asignadas INT,
    PRIMARY KEY (empleado_id, proyecto_id),
    FOREIGN KEY (empleado_id) REFERENCES empleados(id),
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(id)
);

INSERT INTO empleado_proyecto (empleado_id, proyecto_id, horas_asignadas) VALUES
(1, 1, 20),
(2, 2, 30),
(3, 1, 15),
(4, 3, 25),
(5, 2, 35),
(6, 4, 10),
(7, 5, 20),
(8, 3, 15),
(9, 1, 10),
(10, 2, 25);

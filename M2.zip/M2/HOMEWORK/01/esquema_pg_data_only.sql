--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientes (id, nombre, email, fecha_registro) FROM stdin;
3	Martin	martin@inworx.com	2025-05-25
4	Pato	patitoK@gmail.com	2025-06-25
5	Mario	mario@gmail.com	2023-05-25
6	Lucia	lulu@hotmail.com	2020-05-25
7	Carlos	charly@gmail.com	2025-01-01
8	Ciro	ciritoreloco@yahoo.com	2024-12-31
9	Maria	maru@gmail.com	2025-06-01
10	Franco	frankito@gmail.com	2024-03-03
1	Lucas	lucas@gmail.com	2025-06-25
2	Nicolas	niko@gmail.com	2025-06-25
\.


--
-- Data for Name: sucursales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sucursales (id, nombre, ubicacion) FROM stdin;
1	Principal	Martinez
2	Secundaria	Olivos
3	Distribucion	Olivos
4	La Feliz	Mar del Plata
5	Peligrosa	La Matanza
6	Retail	Palermo
7	Oficinas	Belgrano
8	Atencion al cliente	Belgrano
9	Atencion al cliente	Acassusso
10	Cuchillo	Jose C Paz
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.productos (id, nombre, categoria, precio, stock, sucursal_id) FROM stdin;
1	botin pasto sintetico	futbol	100.00	10	8
2	botin 11	futbol	75.50	5	9
3	botin piso	futbol	119.99	15	9
4	pelota	futbol	150.00	14	8
5	zapatilla	tenis	200.50	29	10
7	pelotita	tenis	20.00	40	10
8	palo	hockey	300.75	20	1
6	pelota	basket	130.50	5	4
9	protector bucal	boxeo	150.00	23	2
10	guantes	boxeo	150.00	30	2
\.


--
-- Data for Name: ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventas (id, cliente_id, producto_id, fecha_venta, cantidad, total) FROM stdin;
1	10	3	2025-06-25	5	30
3	8	7	2024-03-03	15	20
4	7	10	2025-03-03	3	30
5	6	1	2025-03-04	10	15
6	5	2	2025-03-30	1	5
7	4	3	2025-05-03	2	20
8	3	5	2025-04-30	1	25
9	2	9	2025-05-31	4	35
10	1	3	2025-06-25	5	9
\.


--
-- PostgreSQL database dump complete
--


-- sucursales (id, nombre, ubicación)

create table sucursales (
	id INT primary key, --deberia ser autoincremental
	nombre VARCHAR(100),
	ubicacion VARCHAR(100)
);

-- productos (id, nombre, categoría, precio, stock, sucursal_id)


create table productos (
	id INT primary key, --deberia ser autoincremental
	nombre varchar(50),
	categoria varchar(100),
	precio float,  -- si quiero cambiar el tipo: ALTER TABLE productos ALTER COLUMN precio TYPE NUMERIC(10,2);
	stock INT,
	sucursal_id INT references sucursales(id) on delete set null -- NULO si se borra sucursal
);

-- alter table productos drop constraint productos_sucursal_id_fkey
-- alter table productos add foreign key (sucursal_id) references sucursales(id) on delete set null;

-- clientes (id, nombre, email, fecha_registro)

create table clientes (
	id INT primary key, --deberia ser autoincremental
	nombre VARCHAR(100),
	email VARCHAR(100),
	fecha_registro date
);

-- ventas (id, cliente_id, producto_id, fecha_venta, cantidad, total)
drop table ventas

create table ventas (
	id INT primary key, --deberia ser autoincremental
	cliente_id INT references clientes(id) on delete set NULL, -- NULO si se borra cliente
	producto_id INT references productos(id) on delete set NULL, -- NULO si se borra producto
	fecha_venta DATE,
	cantidad INT,
	total INT
);






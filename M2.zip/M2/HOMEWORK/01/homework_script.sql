-- Insertar 10 registros en cada tabla.

insert into sucursales values 
(1 , 'Principal', 'Martinez')

insert into sucursales values 
(2 , 'Secundaria', 'Olivos'),
(3 , 'Distribucion', 'Olivos')

insert into sucursales values 
(4 , 'La Feliz', 'Mar del Plata'),
(5 , 'Peligrosa', 'La Matanza'),
(6 , 'Retail', 'Palermo'),
(7 , 'Oficinas', 'Belgrano'),
(8 , 'Atencion al cliente', 'Belgrano'),
(9 , 'Atencion al cliente', 'Acassusso'),
(10 , 'Cuchillo', 'Jose C Paz')


select * from sucursales


insert into productos values 
(1 , 'botin pasto sintetico', 'futbol', 100.00, 10, 8),
(2 , 'botin 11', 'futbol', 75.5, 5, 9),
(3 , 'botin piso', 'futbol', 119.99, 15, 9),
(4 , 'pelota', 'futbol', 150, 14, 8),
(5 , 'zapatilla', 'tenis', 200.5, 29, 10),
(6 , 'pelota', 'basket', 200.00, 5, 4),
(7 , 'pelotita', 'tenis', 20.00, 40, 10),
(8 , 'palo', 'hockey', 300.75, 20, 1),
(9 , 'protector bucal', 'boxeo', 15.00, 23, 2),
(10 , 'guantes', 'boxeo', 250.00, 30, 2)


select * from productos

alter table productos
alter column precio type decimal(10,2)

-- truncate table productos

insert into clientes values 
(1, 'Lucas', 'lucas@gmail.com', now())

insert into clientes values 
(2, 'Nicolas', 'niko@gmail.com', now()),
(3, 'Martin', 'martin@inworx.com', '2025-05-25'),
(4, 'Pato', 'patitoK@gmail.com', now()),
(5, 'Mario', 'mario@gmail.com', '2023-05-25'),
(6, 'Lucia', 'lulu@hotmail.com', '2020-05-25'),
(7, 'Carlos', 'charly@gmail.com', '2025-01-01'),
(8, 'Ciro', 'ciritoreloco@yahoo.com', '2024-12-31'),
(9, 'Maria', 'maru@gmail.com', '2025-06-01'),
(10, 'Franco', 'frankito@gmail.com', '2024-03-03')

delete from clientes where nombre = 'Lucas'

select * from clientes

-- ventas (id, cliente_id, producto_id, fecha_venta, cantidad, total)
insert into ventas values 
(1, 10, 3, now(), 5, 30),
(2, 9, 4, '2024-02-03', 1, 10),
(3, 8, 7, '2024-03-03', 15, 20),
(4, 7, 10, '2025-03-03', 3, 30),
(5, 6, 1, '2025-03-04', 10, 15),
(6, 5, 2, '2025-03-30', 1, 5),
(7, 4, 3, '2025-05-03', 2, 20),
(8, 3, 5, '2025-04-30', 1, 25),
(9, 2, 9, '2025-05-31', 4, 35),
(10, 1, 3, now(), 5, 9)


select * from ventas 

commit;

-- Realizar consultas con JOIN para mostrar los productos vendidos por sucursal y por cliente.

select * from
ventas v
inner join clientes c
on v.cliente_id = c.id
inner join productos p
on v.producto_id = p.id
inner join sucursales s
on p.sucursal_id = s.id


-- productos vendidos por sucursal
select s.id id_sucursal, s.nombre nombre_sucursal, s.ubicacion, p.nombre nombre_producto, v.cantidad cantidad_vendida from
ventas v
inner join productos p
on v.producto_id = p.id
inner join sucursales s
on p.sucursal_id = s.id
order by nombre_sucursal


-- productos vendidos por cliente
select c.id id_cliente, c.nombre, c.email, v.fecha_venta , p.nombre nombre_producto, v.cantidad cantidad_vendida from
ventas v
inner join clientes c
on v.cliente_id = c.id
inner join productos p
on v.producto_id = p.id
order by c.nombre


-- Actualizar precios de productos por categoría.

update productos
set precio = 130.50,
where categoria = 'basket'

update productos
set precio = 150
where categoria = 'boxeo'

select * from productos


-- Eliminar registros de ventas usando transacciones (BEGIN, COMMIT, ROLLBACK).

select * from ventas;

begin transaction;

insert into ventas values 
(2, 9, 4, '2024-02-03', 1, 10);
-- delete from ventas where cliente_id = 9;

rollback;

begin TRANSACTION;
DELETE FROM productos WHERE id = 1;
-- Verifica con un SELECT antes de hacer COMMIT
COMMIT;


-- Crear índices en columnas frecuentemente consultadas (ej: email en clientes, nombre en productos).

CREATE INDEX idx_clientes_email ON clientes(email);
CREATE INDEX idx_productos_nombre ON productos(nombre);


-- Usar EXPLAIN ANALYZE para comparar el rendimiento antes/después de los índices



EXPLAIN analyze  --> deberia aparecer un "index scan" en vez de una busqueda secuencial "seq scan"
select * from productos
where nombre like '%botin%'

-- Exportar el esquema de la base de datos con pg_dump.







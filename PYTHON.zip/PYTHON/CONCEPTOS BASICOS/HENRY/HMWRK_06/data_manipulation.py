import pandas as pd
from pandas import DataFrame

df = pd.read_csv(r" ../data/raw_data.csv")
df.info()

#A)DESCUBRIMIENTO

#-DETECTAR VALORES EXTRAÑOS
#-DETECTAR VALORES NULOS O FALTANTES
#-DETECTAR VALORES NO ESPERADOS

#si el DataType es "object" significa que python no pudo asignarle un tipo al dato.

#primero detectar los valores que son nulos ya sea porque python los reconoce asi o vienen de otro
#sistema que interpreta los nulos de otra forma:
#
#["NA","N/A","null","NULL","nan","NAN",""," ","?"]

#un metodo para verificar en las columnas que figuran como "object" cuando se hace info() es
#convertir esas columnas en string y verificar si existen caracteres extraños (weird).

#tambien hay que verificar que no haya valores no esperados, o fuera del rango de valores esperados.


#B)LIMPIEZA
#EN LA 2DA ETAPA HAY QUE LIMPIAR LOS DATOS (NULOS, DUPLICADOS, VALORES EXTRAÑOS)
#LUEGO UNA VEZ LIMPIO TRATAR DE CONVERTIR LAS COLUMNAS DE TIPO "object" AL VALOR ESPERADO (Int64,string,etc..)
#LUEGO ULITMO ELIMINAR FILAS DUPLICADAS

#POR ULTIMO GUARDAR LOS DATOS LIMPIOS PARA LA SIGUIENTE FASE ANOTANDO LAS OBSERVACIONES Y CONVERSIONES QUE SE HICIERON.


#C)VALIDACION:
#OUTLIERS: SON VALORES ATIPICOS QUE NO SIEMPRE SON ERRORES PERO DISTORSIONAN LOS ANALISIS ESTADSITICOS 
# O ENTRENAMIENTO DE MODELOS. SE DEBE ELIMINAR, REEMPLAZAR O TRANSFORMAR.
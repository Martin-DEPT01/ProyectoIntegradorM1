import pandas as pd
from pandas import DataFrame
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
#from homework_06 import find_weird_values_for_numeric_columns



print("")
df = pd.read_csv(r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\06\cleaned_data.csv")

df_patients_data = pd.read_csv(r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\06\patients_data.csv")

#VERIFICAMOS LA VALIDEZ,VERACIDAD Y PRECISION DE LOS DATOS

df.info()

#print(df.head(10))
#print(df.describe())

#df["time_in_hospital"].plot(kind="hist")
#plt.show()

#print(df[["patient_nbr", "readmitted", "diag_1", "diag_2", "diag_3"]]) #para seleccionar varias columnas se le debe pasar una lista de columnas

df = df[["patient_nbr", "readmitted", "diag_1", "diag_2", "diag_3"]]

#df.info()
#print(df[df.duplicated()].notna().sum())
#HAY FILAS DUPLICADAS 32782 - ES ACEPTABLE SIENDO EL DIAGNOSTICO EL MISMO?

print("----------------------------------------------")
print("TOTAL VALORES NULOS:")
print(df.isnull().sum())

#NO HAY VALORES NULOS

def find_weird_values_for_integer_numeric_columns(df:DataFrame, numeric_columns: list[str]) -> dict[str,str]:
    copy_df: DataFrame = df.copy()

    for column in numeric_columns:
        copy_df[column] = copy_df[column].astype(str)

    unexpected_values: dict = {
        #col: df.loc[~copy_df[col].str.match(r"^-?\d+\.?\d*$", na= True), col].unique().tolist()
        col: df.loc[~copy_df[col].str.match(r"^\d+$", na= True), col].unique().tolist() 
        for col in numeric_columns
        if (~copy_df[col].str.match(r"^\d+$", na= True)).any()
        #if (~copy_df[col].str.match(r"^-?\d+\.?\d*$", na= True)).any()
    }
    return unexpected_values


numeric_columns = ["diag_1",
                   "diag_2",
                   "diag_3"]

weird_values: dict[str,str] = find_weird_values_for_integer_numeric_columns(df, numeric_columns)

print(weird_values)
print("----------------------------------------------")
print("TOTAL WEIRD VALUES POR COLUMNA NUMERICA:")

for column, values in weird_values.items():
    print(column)
    total_valores_raros = df[column].isin(values).sum()
    total_de_columna = df[column].size
    print(total_valores_raros)
    print(f"total: {total_de_columna} porcentaje del total: {round((total_valores_raros/total_de_columna) *100,2)}%")


#TOTAL WEIRD VALUES POR COLUMNA NUMERICA:
#diag_1
#13531
#total: 134276 porcentaje del total: 10.08%
#diag_2
#13179
#total: 134276 porcentaje del total: 9.81%
#diag_3
#16200
#total: 134276 porcentaje del total: 12.06%

#SON PORCENTAJES DESPRECIABLES? - SE PUEDEN ELIMINAR?



#ELIMINAMOS ESTOS VALORES EXTRAÑOS:

def drop_weird_values(df: DataFrame, weird_values: dict[str,str]):

    df_cleaned: DataFrame = df.copy()

    for column, values in weird_values.items():
        if column in df_cleaned.columns:
            df_cleaned = df_cleaned[~df_cleaned[column].isin(values)]
    
    return df_cleaned


df = drop_weird_values(df, weird_values)


df.info()

#VERIFICAMOS SI SE ELIMINARON:
print("VERIFICAMOS SI SE ELIMINARON:")
for column, values in weird_values.items():
    print(column)
    total_valores_raros = df[column].isin(values).sum()
    total_de_columna = df[column].size
    print(total_valores_raros)
    print(f"total: {total_de_columna} porcentaje del total: {round((total_valores_raros/total_de_columna) *100,2)}%")



#AHORA HACEMOS TRANSFORMACION DE TIPO:

def convert_to_expected_dtype(df: DataFrame, expected_dtypes: dict[str, type]):

    df_converted: DataFrame = df.copy()

    for column, dtype in expected_dtypes.items():
        #print(expected_dtypes.items())
        print(column, dtype)
        try:
            df_converted[column] = df_converted[column].astype(dtype)
        except ValueError:
            print(f"⚠️ No se pudo convertir la columna '{column}' a {dtype}. Posibles valores inválidos.")
    
    return df_converted


expected_dtypes: dict[str, type] = {
    "diag_1"	: "Int64",
    "diag_2"	: "Int64",
    "diag_3"	: "Int64",
    "patient_nbr"	: "Int64",
    "readmitted"	: "string"
}


df = convert_to_expected_dtype(df, expected_dtypes)

df.info()


# #   Column       Non-Null Count  Dtype
#---  ------       --------------  -----
# 0   patient_nbr  96706 non-null  Int64
# 1   readmitted   96706 non-null  string
# 2   diag_1       96706 non-null  Int64
# 3   diag_2       96706 non-null  Int64
# 4   diag_3       96706 non-null  Int64

#VEMOS QUE QUEDARON LAS CONVERSIONES DE TIPO HECHAS.


#VERIFICAMOS SI HAY VALORES NUMERICOS FUERA DE RANGO

expected_numeric_values: dict = {
    "diag_1"	: 848,
    "diag_2"	: 923,
    "diag_3"	: 954,
}


def find_unexpected_numeric_values(df: DataFrame, expected_numeric_values: dict[str, int]) -> DataFrame:
    
    categories_to_review: list[str] = list(set(df.columns).intersection(set(expected_numeric_values.keys()))) #set().intersection() es una funcion de la clase set (conjunto de datos)
    if not categories_to_review:
        return DataFrame(columns=["Column", "Unexpected_Values"])
    
    unexpected_values: dict = {
        col: df.loc[~df[col].le(expected_numeric_values[col]), col].unique().tolist()  # ".le()" significa less than (x <= y)
        for col in categories_to_review
        if (~df[col].le(expected_numeric_values[col])).any()  #el any() devuelve true si al menos uno de los valores de la serie booleana es "True". Es como usar el len(...)>0

    }

    return DataFrame({
        "Column": unexpected_values.keys(),
        "Unexpected_Values": unexpected_values.values()
    })


print(find_unexpected_numeric_values(df, expected_numeric_values))
#VEMOS QUE HAY VALORES FUERA DE RANGO


print("VERIFICAMOS METRICAS:")
for column, value in expected_numeric_values.items():
    print(column)
    total_valores_fuera_rango = df[column].gt(value).sum()
    total_de_columna = df[column].size
    print(total_valores_fuera_rango)
    print(f"total: {total_de_columna} porcentaje del total: {round((total_valores_fuera_rango/total_de_columna) *100,2)}%")


#VERIFICAMOS METRICAS:
#diag_1
#3920
#total: 96706 porcentaje del total: 4.05%
#diag_2
#1778
#total: 96706 porcentaje del total: 1.84%
#diag_3
#1468
#total: 96706 porcentaje del total: 1.52%

#COMO SON PORCENTAJES DESPRECIABLES PROCEDEMOS A ELIMINARLOS:

print("COMO SON PORCENTAJES DESPRECIABLES PROCEDEMOS A ELIMINARLOS...")

def drop_unexpected_numeric_values(df: DataFrame, expected_numeric_values: dict[str,int]):

    df_cleaned: DataFrame = df.copy()

    for column, value in expected_numeric_values.items():
        if column in df_cleaned.columns:
            df_cleaned = df_cleaned[~df_cleaned[column].gt(value)]
    
    return df_cleaned



df = drop_unexpected_numeric_values(df, expected_numeric_values)


print("VOLVEMOS A VERIFICAR METRICAS:")
for column, value in expected_numeric_values.items():
    print(column)
    total_valores_fuera_rango = df[column].gt(value).sum()
    total_de_columna = df[column].size
    print(total_valores_fuera_rango)
    print(f"total: {total_de_columna} porcentaje del total: {round((total_valores_fuera_rango/total_de_columna) *100,2)}%")


print(find_unexpected_numeric_values(df, expected_numeric_values))




#YA TENEMOS TODA LA INFO LIMPIA PARA PROCEDER CON LA PUBLICACION...
print("YA TENEMOS TODA LA INFO LIMPIA PARA PROCEDER CON LA PUBLICACION...")


#-----------------------------------------------------------------------------------------------
#Generar un ranking de los 15 pacientes con mayor número de readmisiones hospitalarias. 
# Se requiere presentar el nombre completo, número de paciente y número de celular de cada uno.


#print(df_merged[df_merged["readmitted"].eq("<30")].groupby("patient_nbr")["readmitted"].count())

df_ordenado = df[df["readmitted"].eq("<30")].groupby("patient_nbr")["readmitted"].count().reset_index(name="readmitted <30").sort_values(by="readmitted <30", ascending=False)

df_ordenado.insert(0, "ranking", df_ordenado["readmitted <30"].rank(method="dense", ascending=False).astype(int))

#print(df_ordenado.head(15))

df_merged = pd.merge(df_ordenado, df_patients_data, on="patient_nbr", how="inner").sort_values(by="readmitted <30", ascending=False)

df_merged["name"] = df_merged["first_name"] + " " + df_merged["last_name"]
df_merged["ranking"] = df_merged["readmitted <30"].rank(method="dense", ascending=False).astype(int)
#df_merged.insert(0, "ranking", range(1, len(df_merged) + 1))
df_final = df_merged[["ranking", "name", "patient_nbr", "readmitted <30", "cellphone"]]


#REPORTE 1:
print("REPORTE 1:")
print(df_final.head(15))


#SELECT RANK() AS RANKING, (PN.PATIENT_NAME + PN.PATIENT_SURNAME) AS NAME, COUNT(*) AS "<30" FROM DIABETES DB
#JOIN PATIENTS_NAME PN
#ON DB.PATIENT_NBR = PN.PATIENT_NBR
#WHERE READMITED = "<30"
#GROUP BY PATIENT_NBR
#ORDER BY "<30"
#LIMIT 15


#-----------------------------------------------------------------------------------------------
#Generar un top 10 de los diagnósticos más frecuentes entre los pacientes readmitidos. 
# Ten en cuenta que existen tres columnas relacionadas con diagnósticos: diag_1, diag_2 y diag_3.



#WHERE READMITTED IN (">30","<30")
#GROUP BY DIAGNOSIS

#df.info()

#print(df)

df_filtered = df[df["readmitted"].isin([">30","<30"])]

#print(df_filtered)

#print(df_filtered[["patient_nbr","readmitted","diag_1"]])

#RENOMBRAMOS LAS COLUMNAS ANTES DE CONCATENAR:
df1 = df_filtered[["patient_nbr","readmitted","diag_1"]].rename(columns={"diag_1": "diagnosis"})
df2 = df_filtered[["patient_nbr","readmitted","diag_2"]].rename(columns={"diag_2": "diagnosis"})
df3 = df_filtered[["patient_nbr","readmitted","diag_3"]].rename(columns={"diag_3": "diagnosis"})

#UNION ALL DE LOS DATAFRAME
df_union = pd.concat([df1, df2, df3], axis = 0, ignore_index = True)

#print(df_union)

df_grouped = df_union.groupby("diagnosis")["diagnosis"].count().reset_index(name="total")

#print(df_grouped)

df_grouped.insert(0, "ranking", df_grouped["total"].rank(method="dense", ascending=False).astype(int))

df_ranked = df_grouped.sort_values(by="ranking")


#REPORTE 2:
print("REPORTE 2:")
print(df_ranked.head(10))

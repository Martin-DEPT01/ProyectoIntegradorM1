import pandas as pd
from pandas import DataFrame
import numpy as np


print("")
df = pd.read_csv(r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\06\diabetic_data.csv")
#df.info()

#A) validación de los datos
#B) limpieza
#C) transformación

#analizar los datos de pacientes con diagnóstico de diabetes, con el objetivo de identificar 
# patrones asociados al riesgo de readmisión hospitalaria en menos de treinta (<30) días.

#¿Quiénes son los 15 pacientes que más le cuestan a la compañía?

#¿Cuáles son los diagnósticos que más le cuestan a la compañía?

#1- Generar un ranking de los 15 pacientes con mayor número de readmisiones hospitalarias. 
# Se requiere presentar el nombre completo, número de paciente y número de celular de cada uno.

def find_weird_NAN_representations(df: DataFrame) -> None:

    nan_representations: list[str] = ["NA","N/A","null","NULL","nan","NaN",""," ","?"]
    columns: list[str] = list()
    for column in df.columns:
        #print(df[column])
        #print(f" {column} - {len(df[df[column].isna()])} from {len(df[column])}\n")
        if len(df[df[column].isin(nan_representations)]) > 0:
            #print(len(df[pd.isna(df[column])]))
            #print(f"\n{column} -> {len(df[df[column].isin(nan_representations)])} rows from {len(df[column])} total")
            columns.append(column)
    print(f"NAN representation found for columns {columns}"
          if len(columns) > 0 else
          f"No NAN representation found in columns {columns}")


#######find_weird_NAN_representations(df)
#NAN representation found for columns ['diag_1', 'race', 'diag_2', 'payer_code_2', 'payer_code', 'medical_specialty', 'weight', 'diag_3']


nan_representations: list[str] = ["NA","N/A","null","NULL","nan","NaN",""," ","?"]
#print(nan_representations)
#print(df["diag_1"])
#print(df[df["diag_1"].isin(nan_representations)])
#print(type(df["diag_1"].isin(nan_representations)))
#print(df[df["diag_1"].isin(nan_representations)])
#print(type(df[df["diag_1"].isin(nan_representations)]))
#print(len(df[df["diag_1"].isin(nan_representations)]))

#print("valores unicos")
#print(df["diag_1"].unique())
#df["diag_1"] --> CONTIENE NUMEROS, "?", "abcde" y COMBINACIONES ALFANUMERICAS "V71".

#df = pd.read_csv(r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\06\diabetic_data.csv")
#nan_representations: list[str] = ["NA","N/A","null","NULL","nan","NaN",""," ","?"]
#df[df["diag_1"].isin(nan_representations)]

# --> AHORA REEMPLAZAR ESAS REPRESENTACIONES DE NULOS POR NULOS EN SERIO (NO AHORA)

#print(len(df[pd.isna(df[column])])) --> pareciera que ninguna columna tiene datos nulos reconocidos por python

def find_NAN_no_NAN_match_column_length(df:DataFrame):
    columns: list[str] = list()
    for column in df.columns:
        if len(df[df[column].notna()]) + len(df[df[column].isna()]) != len(df[column]):
            columns.append(column)
            print(column, " ", len(df[df[column].notna()]), " ", len(df[df[column].isna()]), " ",len(df[column]))
    print(f"NAN + not NAN check invalid for columns: {columns}"
           if len(columns) > 0 else 
           "NAN + not NAN check valid for all columns")



print(f"cantidad de columnas NO nulas vs NULAS vs TOTAL diag_1: {len(df[df["diag_1"].notna()])} ; {len(df[df["diag_1"].isna()])} ; {len(df["diag_1"])}")

#print(df[df["diag_1"].notna()].iloc[518])


########find_NAN_no_NAN_match_column_length(df)
#NAN + not NAN check valid for all columns


#nan_representation + (NO nan_representation y NO nulos) + NULOS
#print(df.isin(nan_representations).sum())
#print(" --------------------------------------------------------------------- ")
#print(df.isna().sum())
#print(" --------------------------------------------------------------------- ")
#print(df.isna() | df.isin(nan_representations))
#print(" --------------------------------------------------------------------- ")
#print((df.isna() | df.isin(nan_representations)).sum())
print(" --------------------------------------------------------------------- ")
print((df.isna() | df.isin(nan_representations)).sum()/len(df) * 100)
print(len(df))

#CONCLUSION: hay columnas cuyos valores entre representaciones de NAN y nulos superan el 50% del total y no se pueden utilizar.

#VEAMOS COLUMNAS DUPLICADAS:
######df.info()
print(" --------------------------------------------------------------------- ")
#for col in sorted(df.columns):
#    print(col)
print("COLUMNAS DUPLICADAS:")
print(f"{df["glyburide-metformin"].equals(df["glyburide-metformin_2"])} - columna glyburide-metformin_2")
print(f"{df["metformin-pioglitazone"].equals(df["metformin-pioglitazone_2"])} - columna metformin-pioglitazone_2")
print(f"{df["payer_code"].equals(df["payer_code_2"])} - columna payer_code_2")
print(f"{df["troglitazone"].equals(df["troglitazone_2"])} - columna troglitazone_2")
print(f"{df["US"].equals(df["A1Cresult"])} - columna A1Cresult")

#CONCLUSION: VEMOS QUE ESTAS COLUMNAS ESTAN REPETIDAS: glyburide-metformin_2, metformin-pioglitazone_2, payer_code_2, troglitazone_2


# --> VEAMOS VALORES EXTRAÑOS (WEIRD)

#######df.info()

def find_weird_values_for_numeric_columns(df:DataFrame, numeric_columns: list[str]) -> DataFrame:
    copy_df: DataFrame = df.copy() #no hace falta indicar el tipo "DataFrame" pero se hace para favorecer la lectura y el entendimiento del editor de codigo
    columns: list[str] = list() # "list[str] es para indicar el tipo pero no hace falta"
    masks: list = list()
    total_weird: list = list()
    for column in numeric_columns:
        copy_df[column] = copy_df[column].astype(str)
        mask = ~copy_df[column].str.match(r"^-?\d+\.?\d*$", na= True)
        #print(mask)
        #print(df[mask])
        #print(df[mask][column])
        if len(df[mask][column].unique()) > 0:
            columns.append(column)
            masks.append(df[mask][column].unique())
            total_weird.append(df[mask][column].unique().size)
            #print(df[mask][column].unique())
            #print(df[mask][column].unique().tolist())
            #print(len(df[mask][column].unique().tolist()))
            #print(df[mask][column].unique().size)

    weird_values: DataFrame = DataFrame({         # DataFrame({...}) --> es el contructor de pandas.DataFrame
        "Column": columns, "Weird_Values": masks, "Total_Weird_Values": total_weird
    })
    return weird_values

#numeric_columns = ["encounter_id"]
#Weird_values = find_weird_values_for_numeric_columns(df, numeric_columns)
#Weird_values_T = Weird_values.T
#print(Weird_values)
print(" --------------------------------------------------------------------- ")
#print(Weird_values_T)


numeric_columns = ["patient_nbr",
                   "weight",
                   "admission_type_id",
                   "admission_source_id",
                   "discharge_disposition_id",
                   "time_in_hospital",
                   "num_lab_procedures",
                   "num_procedures",
                   "num_medications",
                   "number_outpatient",
                   "number_emergency",
                   "number_inpatient",
                   "diag_1",
                   "diag_2",
                   "diag_3",
                   "number_diagnoses"]

########weird_values = find_weird_values_for_numeric_columns(df, numeric_columns)
########print(weird_values)

#HAY VALORES NO ESPERADOS EN COLUMNAS NUMERICAS


#--> ANALICEMOS COLUMNAS NO NUMERICAS:

def find_unexpected_values2(df: DataFrame, expected_values: dict[str, str]) -> DataFrame:
    
    categories_to_review: list[str] = list(set(df.columns).intersection(set(expected_values.keys()))) #set().intersection() es una funcion de la clase set (conjunto de datos)
    if not categories_to_review:
        return DataFrame(columns=["Column", "Unexpected_Values"])
    
    unexpected_values: list = list()
    columns: list[str] = list()
    total_unexpected: list = list()
    for column in categories_to_review:
        mask = ~df[column].isin(expected_values[column])
        if len(df[mask][column].unique()) > 0:
            columns.append(column)
            unexpected_values.append(df[mask][column].unique())
            total_unexpected.append(df[mask][column].unique().size)

    dt_unexpected_values: DataFrame = DataFrame({        
        "Column": columns, "Unexpected_Values": unexpected_values, "Total_Unexpected_Values": total_unexpected
    })
    return dt_unexpected_values

        
expected_values: dict = {
    "race" : ["AfricanAmerican", 
              "Asian", 
              "Caucasian", 
              "Hispanic", 
              "Other"],
    "gender" : ["Male", "Female", "Unknown/Invalid"],
    "age" : ["[0-10)",
             "[10-20)",
             "[20-30)",
             "[30-40)",
             "[40-50)",
             "[50-60)",
             "[60-70)",
             "[70-80)",
             "[80-90)",
             "[90-100)"],
    #"admission_source_id" : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]
    "max_glu_serum" : [">200",">300","None","Norm"],
    "A1Cresult" : [">7",">8","None","Norm"],
    "change" : ["No","Ch"],
    "diabetesMed" : ["Yes","No"],
    "readmitted" : ["<30",">30","NO"]
}



#print(find_unexpected_values2(df, expected_values))

#FORMA DE LA CLASE:

def find_unexpected_values(df: DataFrame, expected_values: dict[str, str]) -> DataFrame:
    
    categories_to_review: list[str] = list(set(df.columns).intersection(set(expected_values.keys()))) #set().intersection() es una funcion de la clase set (conjunto de datos)
    if not categories_to_review:
        return DataFrame(columns=["Column", "Unexpected_Values"])
    
    unexpected_values: dict = {
        col: df.loc[~df[col].isin(expected_values[col]), col].unique().tolist()  #esto es comprensión de diccionario. Una forma compacta de crear un diccionario en una sola linea. EJ: "cuadrados = {x: x**2 for x in lista}"
        for col in categories_to_review
        if (~df[col].isin(expected_values[col])).any()  #el any() devuelve true si al menos uno de los valores de la serie booleana es "True". Es como usar el len(...)>0

    }

    return DataFrame({
        "Column": unexpected_values.keys(),
        "Unexpected_Values": unexpected_values.values()
    })


######print(find_unexpected_values(df, expected_values))


#admission_source_id = ['1',2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]
#print(df.loc[~df["admission_source_id"].isin(admission_source_id), "admission_source_id"])

#HAY UN TEMA CON "admission_source_id" ya que tiene valores fuera de rango, de otro tipo, y algunos numeros los interpreta como string.
#VER COMO RESUELVE VALORES EXTRAÑOS EN "payer_code"
#ENTIENDO QUE "medical_specialty" ENTRA EN EL TEMA DE LOS VALORES NULOS --> ?
#NO ESTA EL CAMPO "Glucose serum test result"
#A1Cresult   --> [nan, abcde] --> reconoce "nan" como valor fuera de rango pero no observe valores nulos ni otra nan representation
#print(df["A1Cresult"].unique().tolist()) --> [nan, '>7', '>8', 'Norm', 'abcde'] --> RECONOCE a "NONE" como una nan repreentation



#CONCLUSIONES:
#- NO HAY VALORES NULOS EN SI, PERO SI REPRESENTANCIONES DE NULOS
#- HAY VALORES EXTRAÑOS "abcde"
#- HAY VALORES FUERA DE RANGO ESPERADO
#- HAY DIFERENCIAS ENTRE LA PLANILLA Y EL EXCEL (NOMBRE O EXISTENCIA DE CAMPOS, FORMATO DE VALORES ESPERADOS)

#B) limpieza

#df.info()
#LIMPIAMOS DATOS NULOS NATIVOS O REPRESENTADOS:

#NAN representation found for columns ['diag_1', 'race', 'diag_2', 'payer_code_2', 'payer_code', 'medical_specialty', 'weight', 'diag_3']

nan_representations: list[str] = ["NA","N/A","null","NULL","nan","NaN",""," ","?"]


#limpiamos columnas que tienen gran porcentaje nulo (nativo o representado)
df.drop(columns=["out","medical_specialty","weight"], inplace = True)  # inplace = True --> hace que se modifique el objeto en vez de crear copia

#IMPORTE: VER RESOLUCION CASOS DE "max_glu_serum" y "A1Cresult"

#print((df.isna() | df.isin(nan_representations)).sum()/len(df) * 100)


#LIMPIAMOS COLUMNAS DUPLICADAS:

df.drop(columns = ["glyburide-metformin_2", "metformin-pioglitazone_2", "payer_code_2", "troglitazone_2"], inplace = True)

print((df.isna() | df.isin(nan_representations)).sum()/len(df) * 100)


#ELIMINAMOS VALORES EXTRAÑOS:

def drop_weird_values(df: DataFrame, weird_values: dict[str,str]):

    df_cleaned: DataFrame = df.copy()

    for column, values in weird_values.items():
        if column in df_cleaned.columns:
            df_cleaned = df_cleaned[~df_cleaned[column].isin(values)]
    
    return df_cleaned

weird_values: dict[str,list] = {
    "patient_nbr" : ["abcde"],
    "patient_nbr" : ["abcde"],
    "admission_type_id" : ["abcde"],
    "discharge_disposition_id" : ["abcde"],
    "time_in_hospital" : ["abcde"],
    "num_lab_procedures" : ["abcde"],
    "num_procedures" : ["abcde"],
    "num_medications" : ["abcde"],
    "number_outpatient" : ["abcde"],
    "number_emergency" : ["abcde"],
    "number_inpatient" : ["abcde"],
    "number_diagnoses" : ["abcde"]
}

df_cleaned = drop_weird_values(df, weird_values)

df_cleaned.info()


#HACEMOS TRANSFORMACION DE TIPO:

def convert_to_expected_dtype(df: DataFrame, expected_dtypes: dict[str, type]):

    df_converted: DataFrame = df.copy()

    for column, dtype in expected_dtypes.items():
        #print(expected_dtypes.items())
        print(column, dtype)
        try:
            df_converted[column] = df_converted[column].astype(dtype)
        except ValueError:
            print(f"⚠️ No se pudo convertir la columna '{column}' a {dtype}. Posibles valores inválidos.")
    
    return df_converted


expected_dtypes: dict[str, type] = {
    "A1Cresult"	: "string",
    "acarbose"	: "string",
    "acetohexamide"	: "string",
    #"admission_source_id" : "Int64",
    #"admission_type_id"	: "Int64",
    "age"	: "string",
    "change"	: "string",
    "chlorpropamide"	: "string",
    "citoglipton"	: "string",
    "diabetesMed"	: "string",
    "diag_1"	: "Int64",
    "diag_2"	: "Int64",
    "diag_3"	: "Int64",
    #"discharge_disposition_id"	: "Int64",
    #"encounter_id"	: "Int64",
    "examide"	: "string",
    "gender"	: "string",
    "glimepiride"	: "string",
    "glimepiride-pioglitazone"	: "string",
    "glipizide"	: "string",
    "glipizide-metformin"	: "string",
    "glyburide"	: "string",
    "glyburide-metformin"	: "string",
    "insulin"	: "string",
    "max_glu_serum"	: "string",
    "metformin"	: "string",
    "metformin-pioglitazone"	: "string",
    "metformin-rosiglitazone"	: "string",
    "miglitol"	: "string",
    "name"	: "string",
    "nateglinide"	: "string",
    #"num_lab_procedures"	: "Int64",
    #"num_medications"	: "Int64",
    #"num_procedures"	: "Int64",
    #"number_diagnoses"	: "Int64",
    #"number_emergency"	: "Int64",
    #"number_inpatient"	: "Int64",
    #"number_outpatient"	: "Int64",
    #"patient_nbr"	: "Int64",
    "payer_code"	: "string",
    "pioglitazone"	: "string",
    "race"	: "string",
    "readmitted"	: "string",
    "repaglinide"	: "string",
    "rosiglitazone"	: "string",
    #"time_in_hospital"	: "Int64",
    "tolazamide"	: "string",
    "tolbutamide"	: "string",
    "troglitazone"	: "string",
    "US"	: "string"
}


df_converted = convert_to_expected_dtype(df_cleaned, expected_dtypes)

#df_converted.info()


#ELIMINAMOS COLUMNAS DUPLICADAS:

df_final = df_converted.drop_duplicates(keep="first")

df_final.info()

#CONCLUSIONES:
#- NO PUDE CONVERTIR LAS COLUMNAS QUE TIENEN NUMERO EN FORMATO string A Int64
#- QUEDARON VALORES EXTRAÑOS QUE APARECEN MENOS DEL 50% COMO "?" En "race" 5000 rows. En "payer_code" 59000 rows. TENER EN CUENTA QUE ESAS COLUMNAS NO ME SIRVEN. 
#- EN "A1Cresult" Y "max_glu_serum" QUEDARON VACIAS LOS VALOES "None".


#print(find_unexpected_values(df_final, expected_values))

#GUARDAMOS EL DF LIMPIADO

#df_final.to_csv(r"C:\Users\martin.tedesco\OneDrive - Charles Taylor InsureTech Limited\Desktop\HENRY\DATABASE\HOMEWORK\06\cleaned_data.csv")
a=3
b=2

if (a<b):
    print("a es menor que b")
elif a==b: 
    print("son iguales")
else:
    print("a es mayor que b")

c=True

if type(c) is bool:
    print("c es booleano")

"""--------------------------------------------------------"""
lenguajes=["python","java","golang"]

for elemento in lenguajes:
    if elemento == "python":
        continue
    print(elemento)
    if elemento is "java":
        break

# Iterar sobre un conjunto de numeros consecutivos con "range"

for element in range(5):  # --> range crea una lista empezando en cero hasta el numero anterior al parentesis
    print(element)

for element in range(1,5): # --> imprime del 1 al 4
    print(element)

"""-->WHILE<--"""

i=1
while i<=5:
    if i==1: 
        print("DENTRO DEL WHILE")
    print(i)
    i+=1
    if i== 4:
        break

# ITERAR SOBRE LISTA

lenguajes2=["python","java","golang"]

for elemento in lenguajes2: # --> ITERAMOS CON CADA ELEMENTO DE LA LISTA
    print(elemento)

for index in range(len(lenguajes)): # --> ITERAMOS CON LOS INDICES DE LA LISTA
    print(index)
    print("elemento",lenguajes2[index])

j=0
while j<len(lenguajes2):
    print(lenguajes2[j])
    j+=1

"""ITERAR SOBRE UN DICCIONARIO"""

lenguajes3={
    "nombre":"Python",
    "creador":"Guido van Rossum"
}

for llave in lenguajes3:
    print(llave)
    print(lenguajes3[llave])

print("KEYS")
for keys in lenguajes3.keys():
    print(keys)

print("VALUES")
for values in lenguajes3.values():
    print(values)

print("ITEMS")
for items in lenguajes3.items():
    print(items)

print("ITEMS CAPTURANDO DE A PARES")
for clave,valor in lenguajes3.items():
    print("clave:",clave,"valor:",valor)

print(lenguajes3.items())
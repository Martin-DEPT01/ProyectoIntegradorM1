import csv
import pandas as pd
import numpy as npy


APELLIDO="Colapinto"

def funcion_test():
    print("mi first funcion")
    nombre="Ana"
    print(nombre,APELLIDO)

funcion_test()


def perimetro_cuadrado(lado,unidades):
    perimetro=lado*4
    print(f"el perimetro es: {perimetro} {unidades}")

perimetro_cuadrado(4,"cm")

perimetro_cuadrado(unidades="metros",lado=25)   # OTRA FORMA DE LLAMAR A LA FUNCION
perimetro_cuadrado(lado=25,unidades="metros")   # OTRA FORMA DE LLAMAR A LA FUNCION

#------------------------------------------------------------------------------------

def perimetro_cuadrado2(lado):
    perimetro=lado*4
    #return perimetro

def area_cuadrado(lado):
    area=lado*lado
    return area

perimetro=perimetro_cuadrado2(5)
area=area_cuadrado(5)

print(f"Area: {area}, Perimetro: {perimetro}")

def calcular_cuadrado(lado):
    """vos confia pollo"""
    perimetro=lado*4
    area=lado*lado
    return perimetro, area

perimetro,area=calcular_cuadrado(5)

print(area,perimetro)

def perimetro_cuadrado_comments(lado):
    """Calcular el perimetro de un cuadrado
    
    Esta funcion recibe el valor de un lado de un cuadrado y a partir
    de este calcula y retorna su perimetro
    
    Args:
        lado (int): medida del lado del cuadrado
    
    Returns:
        perimetro (int): perimetro del cuadrado
    """

    perimetro = lado*4
    return perimetro

perimetro_cuadrado_comments(5)

print(""+"Hola")

# mi primer coment
print("hello world!") # otro comment
print("otra impresion")

""" este es un comentario
 multilinea"""

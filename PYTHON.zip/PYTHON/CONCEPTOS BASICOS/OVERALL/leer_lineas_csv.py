#with open("C:/Users/martin.tedesco/OneDrive - Charles Taylor InsureTech Limited/Desktop/HENRY/sales.csv", "r", encoding="utf-8") as file:
#    total_lineas = sum(1 for line in file)
#
#print(f"Total de líneas: {total_lineas - 1}")  # excluye cabecera 


def check_last_line_ending(filepath):
    with open(filepath, 'rb') as f:  # abrir en modo binario para leer bytes exactos
        f.seek(0, 2)  # ir al final del archivo
        filesize = f.tell()

        if filesize == 0:
            return "El archivo está vacío."

        # Vamos retrocediendo para encontrar el final de la última línea
        # Leemos hasta 3 bytes atrás para verificar \r\n o solo \n
        read_size = min(3, filesize)
        f.seek(-read_size, 2)
        tail = f.read(read_size)

        if tail.endswith(b'\r\n'):
            return "La última línea termina con CRLF (\\r\\n)"
        elif tail.endswith(b'\n'):
            return "La última línea termina con LF (\\n)"
        else:
            return "La última línea no termina con salto de línea."

# Ejemplo de uso
#archivo = 'C:/Users/martin.tedesco/OneDrive - Charles Taylor InsureTech Limited/Desktop/HENRY/DATABASE/ProyectoIntegrador/data/sales.csv'
#resultado = check_last_line_ending(archivo)
#print(resultado)

nombre_archivos = [
'categories.csv',
'cities.csv',
'countries.csv',
'customers.csv',
'employees.csv',
'products.csv',
'sales.csv',
]

#ruta = 'C:/Users/martin.tedesco/OneDrive - Charles Taylor InsureTech Limited/Desktop/HENRY/DATABASE/ProyectoIntegrador/data/'
#ruta = 'C:/Users/martin.tedesco/OneDrive - Charles Taylor InsureTech Limited/Desktop/HENRY/'
ruta = 'C:/Users/martin.tedesco/Downloads/'

for arch in nombre_archivos:
    archivo_completo = f'{ruta}{arch}'
    #archivo_completo = ruta + arch
    print(arch)
    #print(f'{ruta}{arch}')
    #print(arch)
    #print(archivo_completo)
    print(check_last_line_ending(archivo_completo))



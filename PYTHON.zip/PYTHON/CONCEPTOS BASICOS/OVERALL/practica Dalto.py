class Animal:
    def __init__(self):
        self.sonido = 'no tiene sonido'

    def hacer_sonido(self):
        return self.sonido


class Perro(Animal):
    def __init__(self):
        self.sonido = 'Guau'


class Gato(Animal):
    def __init__(self):
        self.sonido = 'Miau'
        self._atributo_privado = 'valor'


perro = Perro()
gato = Gato()


print(perro.hacer_sonido())
print(gato.hacer_sonido())

print(gato.sonido)
print(gato._atributo_privado)
>>> programacion=[lenguajes,"dedicacion","practica",lista]
>>> programacion
[['python', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1]]
>>> programacion[0[2]]
<python-input-31>:1: SyntaxWarning: 'int' object is not subscriptable; perhaps you missed a comma?
  programacion[0[2]]
Traceback (most recent call last):
  File "<python-input-31>", line 1, in <module>
    programacion[0[2]]
                 ~^^^
TypeError: 'int' object is not subscriptable
>>> programacion[[02]]
  File "<python-input-32>", line 1
    programacion[[02]]
                  ^
SyntaxError: leading zeros in decimal integer literals are not permitted; use an 0o prefix for octal integers
>>> programacion[0.2]
Traceback (most recent call last):
  File "<python-input-33>", line 1, in <module>
    programacion[0.2]
    ~~~~~~~~~~~~^^^^^
TypeError: list indices must be integers or slices, not float
>>> programacion[0][2]
'golang'

>>> lista=[1,2.0,True,true,"python",1]
Traceback (most recent call last):
  File "<python-input-6>", line 1, in <module>
    lista=[1,2.0,True,true,"python",1]
                      ^^^^
NameError: name 'true' is not defined. Did you mean: 'True'?
>>> lista=[1,2.0,True,"python",1]
>>> lista
[1, 2.0, True, 'python', 1]
>>> lista[0]
1
>>> lenguajes[1]
'java'
>>> len(lenguajes)
3
>>> lenguajes.len()
Traceback (most recent call last):
  File "<python-input-12>", line 1, in <module>
    lenguajes.len()
    ^^^^^^^^^^^^^
AttributeError: 'list' object has no attribute 'len'
>>> len(lista)
5
>>> lenguajes[len(lenguajes)]
Traceback (most recent call last):
  File "<python-input-14>", line 1, in <module>
    lenguajes[len(lenguajes)]
    ~~~~~~~~~^^^^^^^^^^^^^^^^
IndexError: list index out of range
>>> lenguajes[len(lenguajes)-1]
'golang'
>>> lista[-1]
1
>>> lista[-0]
>>> programacion=[lenguajes,"dedicacion","practica",lista]
>>> programacion
[['python', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1]]
>>> programacion[0[2]]
<python-input-31>:1: SyntaxWarning: 'int' object is not subscriptable; perhaps you missed a comma?
  programacion[0[2]]
Traceback (most recent call last):
  File "<python-input-31>", line 1, in <module>
    programacion[0[2]]
                 ~^^^
TypeError: 'int' object is not subscriptable
>>> programacion[[02]]
  File "<python-input-32>", line 1
    programacion[[02]]
                  ^
SyntaxError: leading zeros in decimal integer literals are not permitted; use an 0o prefix for octal integers
>>> programacion[0.2]
Traceback (most recent call last):
  File "<python-input-33>", line 1, in <module>
    programacion[0.2]
    ~~~~~~~~~~~~^^^^^
TypeError: list indices must be integers or slices, not float
>>> programacion[0][2]
'golang'
>>> lenguajes[0] = "AbInitio"
>>> lenguajes
['AbInitio', 'java', 'golang']
>>> programacion.append("final de la lista")
>>> programacion
[['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista']
>>> programacion.extend(programacion)
>>> programacion
[['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', ['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista']
>>> programacion.extend(True)
Traceback (most recent call last):
  File "<python-input-41>", line 1, in <module>
    programacion.extend(True)
    ~~~~~~~~~~~~~~~~~~~^^^^^^
TypeError: 'bool' object is not iterable
>>> programacion.append(True)
>>> programacion
[['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', ['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', True]
>>> lista_vacia=[]
>>> programacion.append(lista_vacia)
>>> programacion
[['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', ['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', True, []]
>>> programacion.extend(lista_vacia)
>>> programacion
[['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', ['AbInitio', 'java', 'golang'], 'dedicacion', 'practica', [1, 2.0, True, 'python', 1], 'final de la lista', True, []]
>>> lenaguajes2=("python","C","C++")
>>> lenguajes2
Traceback (most recent call last):
  File "<python-input-50>", line 1, in <module>
    lenguajes2
NameError: name 'lenguajes2' is not defined. Did you mean: 'lenguajes'?
>>> lenaguajes2
('python', 'C', 'C++')
>>> lenguajes2= "python","C","Java"
>>> lenguajes2
('python', 'C', 'Java')
>>> lenguajes2[0]
'python'
>>> lenguajes2[2]
'Java'
>>> len(lenguajes2)
3
>>> lenguajes2[2]="C++"
Traceback (most recent call last):
  File "<python-input-57>", line 1, in <module>
    lenguajes2[2]="C++"
    ~~~~~~~~~~^^^
TypeError: 'tuple' object does not support item assignment
>>> dicc1={
... "nombre":"Chachi",
... "nacimiento_mes":3
... }
>>> dicc1
{'nombre': 'Chachi', 'nacimiento_mes': 3}
>>> dicc1["nombre"]
'Chachi'
>>> dicc1["año_lanzamiento"]=1993
>>> dicc1
{'nombre': 'Chachi', 'nacimiento_mes': 3, 'año_lanzamiento': 1993}
>>> dicc1["nombre"]=True
>>> dicc1
{'nombre': True, 'nacimiento_mes': 3, 'año_lanzamiento': 1993}
>>> dicc1["extra"]=["testing",True,False,1993]
>>> dicc1
{'nombre': True, 'nacimiento_mes': 3, 'año_lanzamiento': 1993, 'extra': ['testing', True, False, 1993]}
>>> lista_test=[True,False,0,1,2,3,4,5]
>>> dicc1["extra"]=lista_test
>>> dicc1
{'nombre': True, 'nacimiento_mes': 3, 'año_lanzamiento': 1993, 'extra': [True, False, 0, 1, 2, 3, 4, 5]}
>>> dicc1.items
<built-in method items of dict object at 0x0000023E1D237E80>
>>> dicc1.items()
dict_items([('nombre', True), ('nacimiento_mes', 3), ('año_lanzamiento', 1993), ('extra', [True, False, 0, 1, 2, 3, 4, 5])])
>>> dicc1.keys()
dict_keys(['nombre', 'nacimiento_mes', 'año_lanzamiento', 'extra'])
>>> dicc1.values()
dict_values([True, 3, 1993, [True, False, 0, 1, 2, 3, 4, 5]])
>>> set1={1,2,3}
>>> set1
{1, 2, 3}
>>> set2={1,1,2,2,3,4,5}
>>> set2
{1, 2, 3, 4, 5}
>>> set3={1,2,lenguajes2,True,False,1,2.2}
>>> set3
{False, 1, 2, 2.2, ('python', 'C', 'Java')}
>>> lenguajes2.append("Javascript")
Traceback (most recent call last):
  File "<python-input-80>", line 1, in <module>
    lenguajes2.append("Javascript")
    ^^^^^^^^^^^^^^^^^
AttributeError: 'tuple' object has no attribute 'append'
>>> lista_mutable=["C","C++","Javascript"]
>>> set4={1,2,lista_mutable,True,False,1,2.2}
Traceback (most recent call last):
  File "<python-input-82>", line 1, in <module>
    set4={1,2,lista_mutable,True,False,1,2.2}
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
TypeError: unhashable type: 'list'
>>> set1.add(10)
>>> set1
{10, 1, 2, 3}
>>> set1.update(4)
Traceback (most recent call last):
  File "<python-input-85>", line 1, in <module>
    set1.update(4)
    ~~~~~~~~~~~^^^
TypeError: 'int' object is not iterable
>>> set1.update([3,4,34])
>>> set1
{1, 2, 3, 4, 34, 10}
>>> len(set1)
6
>>> len(set2)
5
>>> set2
{1, 2, 3, 4, 5}
>>> set2.discard(6)
>>> set2
{1, 2, 3, 4, 5}
>>> set2.discard(5)
>>> set2
{1, 2, 3, 4}
>>> print(set2.clear())
None
>>> set2
set()
>>>
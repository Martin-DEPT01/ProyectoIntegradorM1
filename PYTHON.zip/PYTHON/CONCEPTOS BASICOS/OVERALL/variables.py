nombre = "Chachi"   #string
edad = 31           #int
altura = 1.71       #float
casado= False       #bool
soltero=True        #bool

print(type (nombre))
print(type (edad))
print(type (altura))
print(type (casado))
print(type (soltero))

#def long_function_name(var_one,
#                         var_two,var_three,
#                         car_four):
#    print("hello_world")
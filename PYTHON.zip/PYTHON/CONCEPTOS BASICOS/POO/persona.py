class Persona:
    atributo =123   #ATRIBUTO DE LA CLASE

    def __init__(self,nombre,edad):  #ATRIBUTOS DE LA INSTANCIA
        self.nombre = nombre
        self.edad = edad
    
    def cumplir_anios(self):
        self.edad+=1
        print(f"Feliz cumpleanios #{self.edad} {self.nombre}")

pedro = Persona("Pedro",20)

pedro.cumplir_anios()

#print(type(pedro))

print(pedro.nombre,pedro.edad,pedro.atributo)

#paco = Persona()

#print(type(paco))

#print(pedro == paco)

"""-->HERENACIA<--"""

class Empleado(Persona):
    def __init__(self,nombre,edad, horas_totales):
        super(Empleado,self).__init__(nombre,edad) #ESTO NOS PERMITE HEREDAR LOS ATRIBUTOS DE LA CLASE PADRE
        self.horas_totales = horas_totales

    def trabajar(self,horas_trabajadas):
        self.horas_totales += horas_trabajadas
        print(f"Usted ha trabajado {horas_trabajadas}")
        print(f"Usted ha trabajado {self.horas_totales}")

paco=Empleado("Paco",25,48)

paco.trabajar(8)
paco.cumplir_anios()
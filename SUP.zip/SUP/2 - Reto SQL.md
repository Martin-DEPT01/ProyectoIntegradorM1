# 🧠 Reto SQL: Análisis de Ventas por País y Vendedor

## 📝 Descripción

En el siguiente reto se pide, mediante la consulta en una base de datos SQL, hacer un ranking de los países con mayores montos de ventas y la cantidad de clientes gestionados en cada uno, el promedio de venta por pais y detectar a los vendedores con mejor desempeño en general y por pais.

Para llevar a cabo las tareas se utilizó **Mysql / Workbench 8.0.41** y se adjunta un archivo .sql para ejecutar las consultas y verificar resultados.

## 📝 Resumen general
El trabajo realizado, se identificó:
* Brasil es el país con mayor monto total de ventas y clientes, seguido de Mexico, Colombia, Perú y Argentina
* El top 3 vendedores con mayor valor de ventas está encabezado por Fernanda Lima y Bruno Souza, ambos de Brasil, seguido por Carlos Lopez de Mexico.
* Cada país posee 2 vendedores y el promedio de venta por vendedor sigue liderado por Brasil, Mexico y Colombia
* El mejor vendedor de cada país es:
    - Mexico: Carlos Lopez
    - Brasil: Fernanda Lima
    - Colombia: Jorge Torres
    - Argentina: Mariana Diaz
    - Perú: Sofia Rojas

## ✅ Preguntas del reto
### 1. Total de clientes por país, ordenado por el monto total en ventas (mayor a menor), incluyendo el ranking del país

**Columnas esperadas: country | total_customers | total_sales | sales_rank**


### 2. Vendedor con mayor valor en ventas, incluyendo su ranking

**Columnas esperadas: seller | total_sales | seller_rank**


### 3. Promedio de ventas por vendedor en cada país

**Columnas esperadas: country | total_sellers | avg_sales_per_seller**


### 4. Vendedores con mayor valor en ventas en cada país.

**Columnas esperadas: country | seller | total_sales**

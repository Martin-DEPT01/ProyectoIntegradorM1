
# Homework M1C4 – SQL Avanzado I

**Escenario:** PaperGalaxy S.A. – Análisis de ventas de artículos de oficina  
**Base de datos:** `sales_office.db`  
**Archivo de soluciones:** `homework_m1c4.sql`

## Descripción
OISDFSADHFJSADF
Este trabajo práctico aplica subconsultas, CTEs y funciones de ventana sobre una base de datos ficticia de ventas de artículos de oficina. El objetivo es ejercitar técnicas avanzadas de SQL para resolver necesidades reales del negocio.

## Contenido del archivo `homework_m1c4.sql`

1. **Subconsultas**
   - `1.a` Subconsulta no correlacionada: productos con precio mayor al promedio global.
   - `1.b` Subconsulta correlacionada: productos con precio superior al promedio de su línea (`PRODUCTLINE`).

2. **CTEs**
   - `2.a` Reescritura de 1.b usando una CTE con `JOIN`.
   - `2.b` Porcentaje de valores nulos en `state` de la tabla `customers`.

3. **CTE recursiva**
   - Obtención de empleados que reportan directa o indirectamente a Mariana (ID 4) y Ricardo (ID 7).

4. **Funciones de ventana**
   - `4.a` Identificación de registros duplicados con `ROW_NUMBER()`.
   - `4.b` Ranking de ventas por año con `RANK()` y `DENSE_RANK()`.
   - `4.c` Cálculo de variación porcentual mensual de ventas con `LAG()`.
   - `4.d` Proyección de ventas del mes siguiente con `LEAD()`.

## Cómo usar

1. Abrir `sales_office.db` con DB Browser for SQLite u otra herramienta.
2. Cargar y ejecutar el contenido de `homework_m1c4.sql`.
3. Analizar los resultados y verificar comprensión.

## Extra credit

Incluye comentarios en las consultas y estructura modular para facilitar la lectura y la extensión del trabajo.

---

**Autor:** Generado automáticamente para fines educativos en el contexto de la clase M1C4 de SoyHenry.
TEST....